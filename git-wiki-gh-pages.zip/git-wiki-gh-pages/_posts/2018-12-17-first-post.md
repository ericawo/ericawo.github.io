---
published: true
---
# First post - An example of blogging

Welcome to Git Wiki first post!

it's a post example and nothing more

you can use Add or Edit buttons to create or edit posts the same way you create pages!
